# Reproduce the pilot

Install requirements.txt, then run `python run_emergence.py --workers 4`. The saved reference output is in evidence/; a fresh run writes results/emergence/. Seeds and hashes are in evidence/manifest.json. Use the recorded Python and library versions for closest reproduction. Existing output is never overwritten. No broker or exchange connection is used.
