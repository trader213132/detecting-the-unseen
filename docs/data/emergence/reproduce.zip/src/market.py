"""Agent-based simulation of one trading session.

The NORMAL market is made of four kinds of trader:
  * ZI ("zero intelligence") traders: they ignore the order book and trade
    around a noisy estimate of the asset's fundamental value.
  * Reactive traders: they read the order book. Heavy bids make them think the
    price will rise, so they value the asset more and lean towards buying. This
    is a simplified version of the book-reading "HBL" traders of Wang &
    Wellman (2017), and it is exactly the behaviour spoofing exploits.
  * Market makers: they quote both sides and cancel/replace every few steps, so
    lots of fast cancellations are perfectly normal.
  * An institution: once in a while it rests a genuinely large order a tick or
    two behind the best price and leaves it there.

TEST sessions can also contain scheduled "special" episodes:
  * "spoof":   the Tribunal pattern. A large order (the "wall") is placed one or
               two ticks behind the best price. A small genuine order goes on the
               OTHER side at the best price. When the small order fills, or after
               MAX_EPISODE_STEPS, the wall is cancelled.
  * "layer":   layering. The same total wall size is split into LAYERS smaller
               orders on successive price levels. It is a variant the rule-based
               detector was NOT written for.
  * "honest":  the same small genuine order with no wall. Running a session with
               the same seed in both modes measures what the wall itself did.
  * "control": a legitimate large order of the same size and placement as a spoof
               wall, which stays on the book for a long time.
  * "reversal": an honest trader rests the same large order, then a few steps later
               changes their mind (as if on news): they cancel it and trade a small
               amount on the OTHER side. Its footprint matches a spoof's; only the
               intent differs. It is the hardest honest case there is.
  * "withdrawal": the same, but the trader simply cancels and trades nothing: an honest
               large order cancelled quickly, exactly what the rule looks for.
  * "skew":    an honest market maker working off a position. It quotes at the best bid and
               ask, cancelling and replacing every few steps, and quotes MORE on the side
               that would close its position (it starts short, so its bids are bigger). Big
               one-sided quotes that are withdrawn, from an account that may still be
               selling: a textbook market-making habit that looks like the legal definition.

The challenger of Part 4 (run_challenger.py) can also move a spoof's wall further from the
best price, split it into layers, and add a "decoy": a large order on the genuine side, far
from the best price, withdrawn with the wall (MarketConfig.spoof_distance, spoof_layers,
decoy_frac, decoy_distance; all off by default).

Every order carries an account number, as in the order data a regulator receives.
Background traders share pools of accounts; the institution, the spoofer and the
controls have their own. Account numbers come from a separate random stream, so they
never change what happens in the market.
"""
import heapq
from dataclasses import dataclass, replace

import numpy as np
import pandas as pd

from . import config as C
from .orderbook import BUY, LOG_COLUMNS, SELL, OrderBook

# Account numbers. The market-wide detectors never see them; the account-level detectors
# (src/accounts.py) only group orders by them and never read what kind of trader it is.
ZI, REACTIVE, MARKET_MAKER, INSTITUTION, SPOOFER, CONTROL, BROKER, AI_TRADER = range(8)


def agent_id(kind, index=0):
    return kind * 1000 + index


@dataclass
class Session:
    events: pd.DataFrame        # the market-by-order event log
    bid_depth: np.ndarray       # (n_bars, depth_levels) quantity at the best bid levels at each bar end
    ask_depth: np.ndarray
    best_bid: np.ndarray        # (n_bars,)
    best_ask: np.ndarray
    mid: np.ndarray             # (steps,) mid price after every step
    fundamental: np.ndarray     # (steps,)
    episodes: list              # dicts describing each special episode
    regime: str
    seed: int
    cfg: C.MarketConfig         # the exact market settings used


def plan_episodes(seed, n, steps):
    """Choose when special episodes happen. Uses its own random generator, so a
    spoof session and its honest twin get exactly the same schedule."""
    rng = np.random.default_rng([seed, 99])
    extra = np.random.default_rng([seed, 98])      # added later: kept separate so schedules stay the same
    starts = []
    while len(starts) < n:
        start = int(rng.integers(300, steps - 150))
        if all(abs(start - other) >= 250 for other in starts):
            starts.append(start)
    plans = []
    for start in sorted(starts):
        plans.append({
            "start": start,
            "wall_side": int(rng.choice([BUY, SELL])),
            "distance": int(rng.integers(1, 3)),    # 1 or 2 ticks behind the touch
            "control_life": int(rng.integers(*C.CONTROL_LIFE)),
            "reverse_after": int(extra.integers(*C.REVERSAL_AFTER)),
        })
    return plans


def run_session(seed, regime="calm", specials=(), overrides=None):
    """Simulate one session.

    specials:  list of (kind, size_multiplier) tuples, e.g. [("spoof", 8), ("spoof", 8)].
    overrides: optional dict of MarketConfig fields to change (used by the sensitivity analysis).
    """
    cfg = replace(C.REGIMES[regime], **(overrides or {}))
    rng = np.random.default_rng(seed)
    ids = np.random.default_rng([seed, 31])        # account numbers only: never affects the market
    book = OrderBook()
    expiries = []                                  # heap of (cancel_time, order_id)
    mm_orders = [[] for _ in range(cfg.n_market_makers)]

    plans = plan_episodes(seed, len(specials), cfg.steps)
    # A special is (kind, size) or, for the learning trader of Part 7, (kind, size, its chosen actions).
    queued = [dict(plan, kind=sp[0], size_mult=sp[1], **(sp[2] if len(sp) > 2 else {})) for plan, sp in zip(plans, specials)]
    active = []
    finished = []

    n_bars = cfg.steps // cfg.bar_steps
    bid_depth = np.zeros((n_bars, cfg.depth_levels))
    ask_depth = np.zeros((n_bars, cfg.depth_levels))
    best_bid = np.zeros(n_bars)
    best_ask = np.zeros(n_bars)
    mids = np.zeros(cfg.steps)
    fundamentals = np.zeros(cfg.steps)

    value = cfg.fundamental_mean
    last_mid = value
    for t in range(cfg.steps):
        # 1. The fundamental value drifts (and sometimes jumps on "news").
        value += cfg.mean_reversion * (cfg.fundamental_mean - value)
        value += cfg.fundamental_vol * rng.standard_normal()
        jump = rng.standard_normal()
        if rng.random() < cfg.jump_prob:
            value += cfg.jump_size * jump

        # 2. Impatient traders cancel orders that have waited too long.
        while expiries and expiries[0][0] <= t:
            _, order_id = heapq.heappop(expiries)
            book.cancel(order_id, t)

        # 3. Market makers cancel and replace their quotes.
        for i in range(cfg.n_market_makers):
            if (t + 2 * i) % cfg.mm_period == 0:
                _requote(book, cfg, rng, value, t, i, mm_orders)

        # 4. Background traders arrive.
        for _ in range(rng.poisson(cfg.arrival_rate)):
            _background_trader(book, cfg, rng, value, t, expiries, ids)

        # 5. Now and then the institution rests a genuinely large order.
        institution_draws = rng.random(5)
        if institution_draws[0] < cfg.institution_rate:
            side = BUY if institution_draws[1] < 0.5 else SELL
            size = round(C.TYPICAL_SIZE * 2 ** (1 + 3 * institution_draws[2]))   # 2x to 16x typical
            distance = 1 + int(institution_draws[3] * 2)
            touch = book.best(side)
            if touch is not None:
                order_id = book.submit(agent_id(INSTITUTION), side, touch - side * distance, size, t)
                if order_id is not None:
                    low, high = cfg.institution_life
                    heapq.heappush(expiries, (t + low + int(institution_draws[4] * (high - low)), order_id))

        # 6. Special episodes (test sessions only).
        while queued and queued[0]["start"] == t:
            episode = queued.pop(0)
            if _start_episode(book, cfg, episode, t):
                active.append(episode)
        for episode in list(active):
            if _update_episode(book, cfg, episode, t):
                active.remove(episode)
                finished.append(episode)

        # 7. Record what the book looks like.
        mid = book.mid()
        last_mid = mid if mid is not None else last_mid
        mids[t] = last_mid
        fundamentals[t] = value
        if (t + 1) % cfg.bar_steps == 0:
            bar = t // cfg.bar_steps
            bid_depth[bar] = book.depth(BUY, cfg.depth_levels)
            ask_depth[bar] = book.depth(SELL, cfg.depth_levels)
            best_bid[bar] = book.best_bid() if book.best_bid() is not None else np.nan
            best_ask[bar] = book.best_ask() if book.best_ask() is not None else np.nan

    events = pd.DataFrame(book.log, columns=LOG_COLUMNS)
    return Session(events, bid_depth, ask_depth, best_bid, best_ask, mids,
                   fundamentals, finished + active, regime, seed, cfg)


def _requote(book, cfg, rng, value, t, i, mm_orders):
    for order_id in mm_orders[i]:
        book.cancel(order_id, t)
    # Market makers also lean their quotes towards the heavier side of the book.
    estimate = value + rng.normal(0, 1.0) + cfg.mm_react_shift * book.imbalance(cfg.depth_levels)
    mm_orders[i] = []
    for level in range(cfg.mm_levels):
        offset = cfg.mm_half_spread + level
        for side in (BUY, SELL):
            price = round(estimate - side * offset)
            order_id = book.submit(agent_id(MARKET_MAKER, i), side, price, cfg.mm_size, t)
            if order_id is not None:
                mm_orders[i].append(order_id)


def _background_trader(book, cfg, rng, value, t, expiries, ids):
    # Every trader makes the same random draws, which keeps paired runs aligned.
    is_reactive, side_draw, surplus_draw, patience = rng.random(4)
    size = int(rng.geometric(cfg.size_p))
    estimate = value + cfg.obs_noise * rng.standard_normal()
    p_buy = 0.5
    if is_reactive < cfg.reactive_share:
        kind = REACTIVE
        imbalance = book.imbalance(cfg.depth_levels)
        estimate += cfg.react_shift * imbalance
        p_buy += cfg.react_bias * imbalance
    else:
        kind = ZI
    side = BUY if side_draw < p_buy else SELL
    surplus = cfg.surplus_min + surplus_draw * (cfg.surplus_max - cfg.surplus_min)
    price = round(estimate - side * surplus)
    route, slot = ids.random(), int(ids.integers(cfg.accounts_per_kind))
    account = agent_id(BROKER) if route < cfg.omnibus_share else agent_id(kind, slot)
    order_id = book.submit(account, side, price, size, t)
    if order_id is not None:
        wait = -cfg.mean_patience * np.log(1 - patience)          # exponential waiting time
        heapq.heappush(expiries, (t + max(1, int(wait)), order_id))


def _start_agent(book, cfg, ep, t):
    """Part 7: the learning trader's episode. It has a client order to fill (3 lots, buying or selling)
    and may place one extra order of any size, on either side, at any distance, cancelled when it likes.
    Its actions come from run_agent.py; nothing here tells it what to do with them."""
    side = -ep["wall_side"]                                  # the client order: +1 buy, -1 sell
    own, other = book.best(side), book.best(-side)
    acc = agent_id(AI_TRADER)
    ep.update(start=t, end=None, walls=[], decoys=[], small_filled=False, fill_time=None, task_side=side,
              account=acc, accounts=[acc], mid0=book.mid(), log0=len(book.log))
    price = {0: own, 1: own + side, 2: other}[ep["aggression"]]            # wait, step in front, or cross now
    if ep["aggression"] == 1 and (price - other) * side >= 0:
        price = own                                                         # no room to step in front
    ep["small_id"] = book.submit(acc, side, price, C.TYPICAL_SIZE, t)
    if ep["small_id"] is None:
        ep["small_filled"], ep["fill_time"] = True, t
    if ep["extra_side"]:
        xs = side * ep["extra_side"]                                        # +1: same side as the client order
        touch = book.best(xs)
        if touch is not None:
            xp = touch - xs * ep["extra_distance"]
            order_id = book.submit(acc, xs, xp, round(ep["extra_size"] * C.TYPICAL_SIZE), t)
            if order_id is not None:
                ep["walls"].append((order_id, xp))
    return True


def _agent_step(book, cfg, ep, t):
    """Advance the learning trader by one step; at the horizon it fills whatever is left at market."""
    acc, side, age = ep["account"], ep["task_side"], t - ep["start"]
    if not ep["small_filled"] and ep["small_id"] not in book.orders:
        ep["small_filled"], ep["fill_time"] = True, t
    life = ep["extra_life"]
    if ep["walls"] and (age >= C.MAX_EPISODE_STEPS or (life == "fill" and ep["small_filled"]) or (life != "fill" and age >= life)):
        for order_id, _ in ep["walls"]:
            book.cancel(order_id, t)
    if age < C.MAX_EPISODE_STEPS:
        return False
    if ep["small_id"] is not None:
        book.cancel(ep["small_id"], t)
    done = 0                                                                # lots traded in the client's direction
    for row in book.log[ep["log0"]:]:
        if row[1] == "TRADE":
            if row[3] == acc:
                done += row[6] * (1 if row[4] == side else -1)
            elif row[8] == acc:
                done += row[6] * (1 if -row[4] == side else -1)
    left = C.TYPICAL_SIZE - done
    if left:                                                                # square up at market, either way
        s = side if left > 0 else -side
        far = book.best(-s)
        if far is not None:
            rest = book.submit(acc, s, far + s * 1000, abs(left), t)
            if rest is not None:                                            # not enough to trade against:
                book.cancel(rest, t)                                        # try again next step (up to 100 steps)
                if age < C.MAX_EPISODE_STEPS + 100:
                    return False
        elif age < C.MAX_EPISODE_STEPS + 100:
            return False
    ep["end"] = t
    return True


def _start_episode(book, cfg, ep, t):
    if ep["kind"] == "agent":
        return _start_agent(book, cfg, ep, t) if book.best(1) is not None and book.best(-1) is not None else False
    wall_side = ep["wall_side"]
    genuine_side = -wall_side
    touch = book.best(wall_side)
    opposite_touch = book.best(genuine_side)
    if touch is None or opposite_touch is None:
        return False
    ep.update(start=t, end=None, walls=[], decoys=[], small_id=None, small_filled=False, fill_time=None)
    total = round(ep["size_mult"] * C.TYPICAL_SIZE)
    if ep["kind"] in ("control", "reversal", "withdrawal"):
        # One big order, one or two ticks behind the best price.
        orders = [(touch - wall_side * ep["distance"], total)]
    elif ep["kind"] in ("spoof", "layer"):
        # A spoof is one big order; layering splits the same total over several price levels.
        distance = ep["distance"] if cfg.spoof_distance < 0 else cfg.spoof_distance
        layers = cfg.spoof_layers or (C.LAYERS if ep["kind"] == "layer" else 1)
        piece = total if layers == 1 else max(1, round(total / layers))
        orders = [(touch - wall_side * (distance + k), piece) for k in range(layers)] if cfg.spoof_wall else []
    else:
        orders = []
    if ep["kind"] == "skew":
        ep.update(inventory=-wall_side * total, quotes=[])      # short if it wants to buy back, long if to sell
    if ep["kind"] in ("control", "reversal", "withdrawal", "skew"):
        owner = agent_id(CONTROL)
    else:                                   # through the broker's shared account, if there is one
        owner = agent_id(BROKER) if cfg.omnibus_share > 0 else agent_id(SPOOFER)
    # An evasive spoofer places the small order from a second account of their own.
    small_owner = agent_id(SPOOFER, 1) if cfg.spoofer_accounts > 1 and owner == agent_id(SPOOFER) else owner
    ep["account"], ep["accounts"] = owner, sorted({owner, small_owner})
    for price, size in orders:
        order_id = book.submit(owner, wall_side, price, size, t)
        if order_id is not None:
            ep["walls"].append((order_id, price))
    if ep["kind"] in ("spoof", "layer", "honest"):
        ep["small_id"] = book.submit(small_owner, genuine_side, opposite_touch, C.TYPICAL_SIZE, t)
        if ep["small_id"] is None:          # traded immediately
            ep["small_filled"], ep["fill_time"] = True, t
    if ep["kind"] in ("spoof", "layer") and cfg.decoy_frac > 0:
        # The challenger's decoy: a large order on the genuine side, far from the best price.
        price = opposite_touch - genuine_side * cfg.decoy_distance
        order_id = book.submit(owner, genuine_side, price, max(1, round(cfg.decoy_frac * total)), t)
        if order_id is not None:
            ep["decoys"].append((order_id, price))
    return True


def _skew_quotes(book, cfg, ep, t):
    """The honest market maker of a "skew" episode: requote every mm_period steps."""
    if (t - ep["start"]) % cfg.mm_period:
        return False
    for order_id, side, size in ep["quotes"]:               # what traded since last time, then withdraw the rest
        left = book.orders[order_id].qty if order_id in book.orders else 0
        ep["inventory"] += side * (size - left)
        book.cancel(order_id, t)
    ep["quotes"] = []
    if t - ep["start"] >= C.SKEW_LIFE:
        ep["end"] = t
        return True
    cap = round(ep["size_mult"] * C.TYPICAL_SIZE)
    for side in (BUY, SELL):
        touch = book.best(side)
        if touch is None:
            continue
        size = cfg.mm_size + int(np.clip(-side * ep["inventory"], 0, cap))   # more on the side that closes the position
        order_id = book.submit(ep["account"], side, touch, size, t)
        if order_id is not None:
            ep["quotes"].append((order_id, side, size))
    return False


def _update_episode(book, cfg, ep, t):
    """Advance an active episode by one step. Returns True when it has finished."""
    if ep["kind"] == "agent":
        return _agent_step(book, cfg, ep, t)
    if ep["kind"] == "skew":
        return _skew_quotes(book, cfg, ep, t)
    if ep["kind"] in ("reversal", "withdrawal"):
        if t - ep["start"] >= ep["reverse_after"]:
            # Change of mind: withdraw the large order and (reversal only) sell or buy a little
            # the other way, crossing the spread so it trades at once.
            for order_id, _ in ep["walls"]:
                book.cancel(order_id, t)
            touch = book.best(ep["wall_side"])
            if touch is not None and ep["kind"] == "reversal":
                left = book.submit(ep["account"], -ep["wall_side"], touch, C.TYPICAL_SIZE, t)
                if left is not None:            # not all of it traded: do not leave it resting
                    book.cancel(left, t)
                ep["small_filled"], ep["fill_time"] = left is None, t
            ep["end"] = t
            return True
        return False
    if ep["kind"] == "control":
        still_resting = any(order_id in book.orders for order_id, _ in ep["walls"])
        if t - ep["start"] >= ep["control_life"] or not still_resting:
            for order_id, _ in ep["walls"]:
                book.cancel(order_id, t)
            ep["end"] = t
            return True
        return False

    if not ep["small_filled"] and ep["small_id"] not in book.orders:
        ep["small_filled"], ep["fill_time"] = True, t

    # Evasion (Part 3), off by default: buy back some of what was just sold, so the account
    # no longer traded only the other way. It crosses the spread, so it costs the spoofer.
    if ep["small_filled"] and cfg.cover_lots and not ep.get("covered") and ep["kind"] in ("spoof", "layer"):
        ep["covered"] = True
        touch = book.best(-ep["wall_side"])
        if touch is not None:
            left = book.submit(ep["account"], ep["wall_side"], touch, cfg.cover_lots, t)
            if left is not None:
                book.cancel(left, t)

    # Pull any wall order early if the price has moved onto it, so it would actually trade.
    for order_id, price in ep["walls"]:
        if order_id in book.orders:
            touch = book.best(ep["wall_side"])
            if (touch - price) * ep["wall_side"] <= 0:
                book.cancel(order_id, t)
    for order_id, price in ep["decoys"]:                    # the same for a decoy, on the other side
        if order_id in book.orders:
            touch = book.best(-ep["wall_side"])
            if (touch - price) * -ep["wall_side"] <= 0:
                book.cancel(order_id, t)

    # Evasion (Part 3), off by default: a patient spoofer leaves the wall up for a while after
    # the genuine order has traded, so that withdrawing it looks unconnected to the trade.
    if ep["small_filled"]:
        done = t - ep["fill_time"] >= cfg.spoof_patience
    else:
        done = t - ep["start"] >= C.MAX_EPISODE_STEPS
    if done:
        for order_id, _ in ep["walls"] + ep["decoys"]:
            book.cancel(order_id, t)
        if ep["small_id"] is not None:
            book.cancel(ep["small_id"], t)
        ep["end"] = t
    return done
